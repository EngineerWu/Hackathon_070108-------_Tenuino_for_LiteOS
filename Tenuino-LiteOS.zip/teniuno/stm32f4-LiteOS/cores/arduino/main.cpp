/*
 Entry
 Part of Tenuino - http://www.tenux.org. or http://www.tenux.cn.
 Copyright (c) 2016-2017 by Tenux maker space, All rights reserved.
 
 * Board:   Tenuino UNO
 * IDE:     MDK 5.17
 * Version: 1.0.00
 * Date:    2016/10/08-2017/01/08
 * Author:  Wangshb
 * Memo:    Entry for whole system
 */  

#define ARDUINO_MAIN
#include "Arduino.h"
/* LiteOS header file */
#include "los_base.h"
#include "los_config.h"
#include "los_typedef.h"
#include "los_hwi.h"
#include "los_task.ph"
#include "los_sem.h"
#include "los_event.h"
#include "los_memory.h"
#include "los_queue.ph"

__IO uint32_t TimingMillis;

static UINT32 ArduinoTskID;

VOID ArduinoTask(VOID);

void TimeTick_Increment(void)
{
  TimingMillis++;
}

/*
 * \brief Main entry point of Arduino application
 */
UINT32 osAppInit( void )
{
    UINT32 uwRet = LOS_OK;
    TSK_INIT_PARAM_S ctsk;
    
    init();
    TimingMillis=0;

    //delay(1);

#if defined(USBCON)
    //USBDevice.attach();
#endif
    
    ctsk.uwResved = LOS_TASK_STATUS_DETACHED;
    ctsk.pfnTaskEntry = (TSK_ENTRY_FUNC)ArduinoTask;
    ctsk.usTaskPrio = OS_TASK_PRIORITY_LOWEST-1;
    ctsk.uwStackSize = LOSCFG_BASE_CORE_TSK_DEFAULT_STACK_SIZE;
    ctsk.pcName = "Arduino Task";
    uwRet = LOS_TaskCreate(&ArduinoTskID,&ctsk);
    return uwRet;
}

/*
 * \brief Loop entry point of Arduino application
 */
VOID ArduinoTask(VOID)
{
    setup();
    
    for (;;)
    {
        loop();
        if (serialEventRun) serialEventRun();
    }
}
