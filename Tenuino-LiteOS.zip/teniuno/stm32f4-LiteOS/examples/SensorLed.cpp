/*
 感应灯
 Part of Tenuino - http://www.tenux.org. or http://www.tenux.cn.
 Copyright (c) 2016-2017 by Tenux maker space, All rights reserved.
 
 * Board:   Tenuino UNO
 * 开发环境: MDK 5.17
 * 版本:     1.0.00
 * 创建日期: 2017/01/08-2017/01/08
 * 作者:     张迪
 * 描述:     当有人经过时LED会自动亮起，人走了LED会自动关闭
 */  

#include "Arduino.h"
void setup();
void loop();

int sensorPin = 6;                           //传感器连接到数字6
int ledPin =  13;                            //LED连接到数字13
int sensorState = 0;                         //变量sensorState用于存储传感器状态

void setup() {
  pinMode(ledPin, OUTPUT);                   //LED为输出设备
  pinMode(sensorPin, INPUT);                 //传感器为输入设备
}

void loop(){
  sensorState = digitalRead(sensorPin);      //读取传感器的值
  
  if (sensorState == HIGH) {                 //如果为高，LED亮
    digitalWrite(ledPin, HIGH); 
    delay(3000);                             //延时3秒
  } 
  else {                                     //否则，LED灭
    digitalWrite(ledPin, LOW); 
  }
}

